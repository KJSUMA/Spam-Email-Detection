import numpy as np
import pandas as pd
import nltk
import string
import joblib
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

# Download required NLTK data
nltk.download("stopwords")
nltk.download("wordnet")

# Load dataset
data = pd.read_csv('spam.csv', encoding='ISO-8859-1')
data = data.drop(columns=["Unnamed: 2", "Unnamed: 3", "Unnamed: 4"])
data = data.rename(columns={'v1': 'category', 'v2': 'text'})

# Convert labels to numeric values
data['category'] = data['category'].map({'ham': 0, 'spam': 1})

# Remove duplicates
data.drop_duplicates(inplace=True)

lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

# Preprocessing function
def process(text):
    text = ''.join([char for char in text if char not in string.punctuation])  # Remove punctuation
    words = text.lower().split()
    words = [lemmatizer.lemmatize(word) for word in words if word not in stop_words]  # Remove stopwords & lemmatize
    return " ".join(words)

# Apply preprocessing
data['cleaned_text'] = data['text'].apply(process)

# Vectorization using TF-IDF
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(data['cleaned_text'])
y = data['category']

# Split data
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)

# Train Naïve Bayes model with optimized alpha
classifier = MultinomialNB(alpha=0.1)  # Default alpha=1, lower alpha means less smoothing
classifier.fit(x_train, y_train)

# Save model and vectorizer
joblib.dump(classifier, 'spam_classifier.pkl')
joblib.dump(vectorizer, 'vectorizer.pkl')

# Evaluate model
train_acc = accuracy_score(y_train, classifier.predict(x_train))
test_acc = accuracy_score(y_test, classifier.predict(x_test))

print(f"Train Accuracy: {train_acc:.4f}")
print(f"Test Accuracy: {test_acc:.4f}")
print("Model and vectorizer saved successfully!")

# font-family: 'Poppins', sans-serif;
#             background: linear-gradient(135deg, #1e1e1e, #3a3a3a);
#             color: #fff;
#             display: flex;
#             justify-content: center;
#             align-items: center;
#             height: 100vh;
#             margin: 0;